# -*- coding: utf-8 -*-
"""Gera o conteúdo-teste (JSON do app + PDF de revisão) a partir de content_virus.py.

uso: python3 build_content.py <pasta do projeto flutter> [pasta extra para cópia do PDF]
"""
import json
import os
import re
import shutil
import sys

from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT, TA_CENTER
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (BaseDocTemplate, Flowable, Frame, KeepTogether, NextPageTemplate, PageBreak, PageTemplate,
                                Paragraph, Spacer, Table, TableStyle)

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import content_virus as C  # noqa: E402

PROJ = sys.argv[1] if len(sys.argv) > 1 else os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))
EXTRA = sys.argv[2] if len(sys.argv) > 2 else None
FONTS = os.path.join(PROJ, 'assets', 'fonts')
OUT_DIR = os.path.join(PROJ, 'assets', 'content', 'informatica_virus')
os.makedirs(OUT_DIR, exist_ok=True)

for name, file in [('B', 'Barlow-Regular'), ('B-M', 'Barlow-Medium'), ('B-SB', 'Barlow-SemiBold'), ('B-B', 'Barlow-Bold'),
                   ('BC-SB', 'BarlowCondensed-SemiBold'), ('BC-B', 'BarlowCondensed-Bold'), ('BC-M', 'BarlowCondensed-Medium')]:
    pdfmetrics.registerFont(TTFont(name, os.path.join(FONTS, file + '.ttf')))
pdfmetrics.registerFontFamily('B', normal='B', bold='B-B', italic='B', boldItalic='B-B')

NAVY = colors.HexColor('#0A1220')
NAVY2 = colors.HexColor('#111C30')
PANEL = colors.HexColor('#16243D')
GOLD = colors.HexColor('#E0B23A')
GOLD2 = colors.HexColor('#F5C842')
INK = colors.HexColor('#18212F')
MUTED = colors.HexColor('#5B6B84')
LINE = colors.HexColor('#D5DCE8')
ZEBRA = colors.HexColor('#F3F6FA')
RED = colors.HexColor('#C2410C')
TEAL = colors.HexColor('#0F766E')

BRANCH = ['#2563EB', '#0E9F6E', '#7C3AED', '#C2410C', '#B91C1C', '#0891B2', '#A16207', '#475569', '#BE185D', '#15803D']


def md(text):
    """**negrito** → <b>; escapa &, <, >."""
    t = text.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
    return re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', t)


S = {
    'body': ParagraphStyle('body', fontName='B', fontSize=10.2, leading=14.6, textColor=INK, spaceAfter=6),
    'h3': ParagraphStyle('h3', fontName='BC-B', fontSize=12.5, leading=15, textColor=NAVY, spaceBefore=6, spaceAfter=4, keepWithNext=1),
    'bullet': ParagraphStyle('bullet', fontName='B', fontSize=10.2, leading=14.2, textColor=INK, leftIndent=14, bulletIndent=3, spaceAfter=3, bulletFontName='B-B', bulletColor=GOLD, bulletFontSize=11),
    'cell': ParagraphStyle('cell', fontName='B', fontSize=9.2, leading=12.2, textColor=INK),
    'cellb': ParagraphStyle('cellb', fontName='B-SB', fontSize=9.2, leading=12.2, textColor=NAVY),
    'head': ParagraphStyle('head', fontName='BC-B', fontSize=9.5, leading=12, textColor=colors.white),
    'note': ParagraphStyle('note', fontName='B', fontSize=8.6, leading=11.5, textColor=MUTED, spaceAfter=6),
    'ctitle': ParagraphStyle('ctitle', fontName='BC-B', fontSize=10.5, leading=13, textColor=GOLD2),
    'ctext': ParagraphStyle('ctext', fontName='B', fontSize=9.8, leading=13.8, textColor=colors.white),
    'ctext_dark': ParagraphStyle('ctext_dark', fontName='B', fontSize=9.8, leading=13.8, textColor=INK),
    'q': ParagraphStyle('q', fontName='B', fontSize=10.3, leading=14.6, textColor=INK),
    'qc': ParagraphStyle('qc', fontName='B', fontSize=9.6, leading=13.4, textColor=INK),
}


class SectionTitle(Flowable):
    def __init__(self, text, width):
        super().__init__()
        self.text, self.w = text, width
        self.height = 36
        self.keepWithNext = 1

    def wrap(self, aw, ah):
        return aw, self.height

    def draw(self):
        c = self.canv
        c.setFillColor(GOLD)
        c.rect(0, 14, 4, 16, stroke=0, fill=1)
        c.setFillColor(NAVY)
        c.setFont('BC-B', 17)
        c.drawString(12, 17, self.text.upper())
        c.setStrokeColor(LINE)
        c.setLineWidth(0.8)
        c.line(0, 8, self.w, 8)


def callout(style, title, text, width):
    if style == 'exam':
        bg, border, tcol, body = NAVY2, GOLD, GOLD2, S['ctext']
        label = title.upper()
    elif style == 'key':
        bg, border, tcol, body = colors.HexColor('#FFF7E0'), GOLD, colors.HexColor('#8A6100'), S['ctext_dark']
        label = title.upper()
    else:
        bg, border, tcol, body = colors.HexColor('#FDEEEA'), RED, RED, S['ctext_dark']
        label = title.upper()
    ts = ParagraphStyle('t', parent=S['ctitle'], textColor=tcol)
    t = Table([[Paragraph(label, ts)], [Paragraph(md(text), body)]], colWidths=[width])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), bg),
        ('LINEBEFORE', (0, 0), (0, -1), 3.5, border),
        ('LEFTPADDING', (0, 0), (-1, -1), 12), ('RIGHTPADDING', (0, 0), (-1, -1), 12),
        ('TOPPADDING', (0, 0), (-1, 0), 9), ('BOTTOMPADDING', (0, -1), (-1, -1), 10),
        ('TOPPADDING', (0, 1), (-1, -1), 2), ('BOTTOMPADDING', (0, 0), (-1, 0), 2),
    ]))
    return KeepTogether([Spacer(1, 4), t, Spacer(1, 8)])


def table(head, rows, widths, width):
    data = [[Paragraph(h.upper(), S['head']) for h in head]]
    for r in rows:
        data.append([Paragraph(md(r[0]), S['cellb'])] + [Paragraph(md(x), S['cell']) for x in r[1:]])
    t = Table(data, colWidths=[w * width for w in widths], repeatRows=1)
    style = [
        ('BACKGROUND', (0, 0), (-1, 0), NAVY),
        ('LINEBELOW', (0, 0), (-1, 0), 1.5, GOLD),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('LEFTPADDING', (0, 0), (-1, -1), 7), ('RIGHTPADDING', (0, 0), (-1, -1), 7),
        ('TOPPADDING', (0, 0), (-1, -1), 5), ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
        ('LINEBELOW', (0, 1), (-1, -1), 0.4, LINE),
    ]
    for i in range(1, len(data)):
        if i % 2 == 0:
            style.append(('BACKGROUND', (0, i), (-1, i), ZEBRA))
    t.setStyle(TableStyle(style))
    return [Spacer(1, 3), t, Spacer(1, 9)]


def bullets(items):
    return [Paragraph(md(x), S['bullet'], bulletText='•') for x in items] + [Spacer(1, 4)]


class MindMap(Flowable):
    """Mapa mental em duas colunas, ligado ao centro por curvas."""

    def __init__(self, spec, width, height):
        super().__init__()
        self.spec, self.w, self.h = spec, width, height

    def wrap(self, aw, ah):
        return self.w, self.h

    def draw(self):
        c = self.canv
        w, h = self.w, self.h
        cx, cy = w / 2, h / 2
        rw, rh = 196, 84
        bw = 244
        gap = 14
        left, right = self.spec['left'], self.spec['right']

        def heights(items):
            return [36 + 17 * len(b['items']) for b in items]

        def layout(side, items, x):
            hs = heights(items)
            total = sum(hs) + gap * (len(items) - 1)
            y = cy + total / 2
            out = []
            for b, bh in zip(items, hs):
                out.append((x, y - bh, bh, b))
                y -= bh + gap
            return out

        L = layout('L', left, 0)
        R = layout('R', right, w - bw)
        # conectores
        c.setLineWidth(1.6)
        for i, (x, y, bh, b) in enumerate(L):
            col = colors.HexColor(BRANCH[i % len(BRANCH)])
            c.setStrokeColor(col)
            p = c.beginPath()
            sx, sy = cx - rw / 2, cy
            ex, ey = x + bw, y + bh / 2
            p.moveTo(sx, sy)
            p.curveTo(sx - 45, sy, ex + 45, ey, ex, ey)
            c.drawPath(p, stroke=1, fill=0)
        for i, (x, y, bh, b) in enumerate(R):
            col = colors.HexColor(BRANCH[(i + len(L)) % len(BRANCH)])
            c.setStrokeColor(col)
            p = c.beginPath()
            sx, sy = cx + rw / 2, cy
            ex, ey = x, y + bh / 2
            p.moveTo(sx, sy)
            p.curveTo(sx + 45, sy, ex - 45, ey, ex, ey)
            c.drawPath(p, stroke=1, fill=0)
        # raiz
        c.setFillColor(NAVY)
        c.setStrokeColor(GOLD)
        c.setLineWidth(2)
        c.roundRect(cx - rw / 2, cy - rh / 2, rw, rh, 10, stroke=1, fill=1)
        c.setFillColor(GOLD2)
        c.setFont('BC-B', 18)
        c.drawCentredString(cx, cy + 5, self.spec['root'])
        c.setFillColor(colors.white)
        c.setFont('B', 11)
        c.drawCentredString(cx, cy - 15, self.spec.get('rootSub', ''))
        # ramos
        for idx, (x, y, bh, b) in enumerate(L + R):
            col = colors.HexColor(BRANCH[idx % len(BRANCH)])
            c.setFillColor(colors.white)
            c.setStrokeColor(col)
            c.setLineWidth(1.2)
            c.roundRect(x, y, bw, bh, 7, stroke=1, fill=1)
            c.setFillColor(col)
            c.roundRect(x, y + bh - 25, bw, 25, 7, stroke=0, fill=1)
            c.rect(x, y + bh - 25, bw, 9, stroke=0, fill=1)
            c.setFillColor(colors.white)
            c.setFont('BC-B', 13)
            c.drawString(x + 10, y + bh - 17.5, b['label'].upper())
            c.setFont('B', 10.4)
            yy = y + bh - 41
            for it in b['items']:
                c.setFillColor(col)
                c.circle(x + 13, yy + 3.5, 2, stroke=0, fill=1)
                c.setFillColor(INK)
                c.drawString(x + 21, yy, it)
                yy -= 17


class QuestionBox(Flowable):
    def __init__(self, n, text, width):
        super().__init__()
        self.n, self.text, self.w = n, text, width
        self.p = Paragraph(md(text), S['q'])

    def wrap(self, aw, ah):
        pw, ph = self.p.wrap(self.w - 112, ah)
        self.ph = ph
        self.height = max(ph, 26) + 14
        return self.w, self.height

    def draw(self):
        c = self.canv
        h = self.height
        c.setFillColor(NAVY)
        c.roundRect(0, h - 30, 26, 24, 5, stroke=0, fill=1)
        c.setFillColor(GOLD2)
        c.setFont('BC-B', 13)
        c.drawCentredString(13, h - 23, f'{self.n:02d}')
        self.p.drawOn(c, 36, h - 6 - self.ph)
        # caixas C / E
        x0 = self.w - 66
        for i, lab in enumerate(['C', 'E']):
            x = x0 + i * 34
            c.setStrokeColor(MUTED)
            c.setLineWidth(1)
            c.roundRect(x, h - 28, 26, 22, 4, stroke=1, fill=0)
            c.setFillColor(MUTED)
            c.setFont('BC-B', 12)
            c.drawCentredString(x + 13, h - 22, lab)
        c.setStrokeColor(LINE)
        c.setLineWidth(0.5)
        c.line(0, 2, self.w, 2)


def build_pdf(path):
    W, H = A4
    M = 18 * mm
    doc = BaseDocTemplate(path, pagesize=A4, leftMargin=M, rightMargin=M, topMargin=22 * mm, bottomMargin=18 * mm,
                          title=f"{C.MATERIAL['title']} — Mentor Policial", author='Mentor Policial',
                          subject=C.MATERIAL['subtitle'], creator='Mentor Policial')
    fw = W - 2 * M

    def header(c, d):
        c.saveState()
        c.setFillColor(NAVY)
        c.rect(0, H - 13 * mm, W, 13 * mm, stroke=0, fill=1)
        c.setFillColor(GOLD)
        c.rect(0, H - 13 * mm - 2, W, 2, stroke=0, fill=1)
        c.setFont('BC-B', 10.5)
        c.setFillColor(GOLD2)
        c.drawString(M, H - 8.3 * mm, 'MENTOR POLICIAL')
        c.setFillColor(colors.HexColor('#8EA0BC'))
        c.setFont('BC-SB', 9.5)
        c.drawRightString(W - M, H - 8.3 * mm, 'INFORMÁTICA · VÍRUS E OUTROS CÓDIGOS MALICIOSOS')
        c.setFont('B', 8)
        c.setFillColor(MUTED)
        c.drawString(M, 10 * mm, f"Material v{C.MATERIAL['version']} · {C.MATERIAL['status'].lower()}")
        c.drawRightString(W - M, 10 * mm, str(d.page))
        c.restoreState()

    def header_land(c, d):
        c.saveState()
        LW, LH = landscape(A4)
        c.setFillColor(NAVY)
        c.rect(0, LH - 13 * mm, LW, 13 * mm, stroke=0, fill=1)
        c.setFillColor(GOLD)
        c.rect(0, LH - 13 * mm - 2, LW, 2, stroke=0, fill=1)
        c.setFont('BC-B', 10.5)
        c.setFillColor(GOLD2)
        c.drawString(M, LH - 8.3 * mm, 'MENTOR POLICIAL · MAPA MENTAL')
        c.setFillColor(colors.HexColor('#8EA0BC'))
        c.setFont('BC-SB', 9.5)
        c.drawRightString(LW - M, LH - 8.3 * mm, 'INFORMÁTICA · VÍRUS E OUTROS CÓDIGOS MALICIOSOS')
        c.setFont('B', 8)
        c.setFillColor(MUTED)
        c.drawRightString(LW - M, 9 * mm, str(d.page))
        c.restoreState()

    def cover(c, d):
        c.saveState()
        c.setFillColor(NAVY)
        c.rect(0, 0, W, H, stroke=0, fill=1)
        # faixa de isolamento
        c.setFillColor(GOLD2)
        c.rect(0, H - 34 * mm, W, 11 * mm, stroke=0, fill=1)
        c.setFillColor(NAVY)
        c.setFont('BC-B', 11)
        txt = 'MENTOR POLICIAL   //   CICLO BÁSICO   //   '
        x = -20
        while x < W:
            c.drawString(x, H - 30.3 * mm, txt)
            x += c.stringWidth(txt, 'BC-B', 11)
        # grade sutil
        c.setStrokeColor(colors.HexColor('#13203A'))
        c.setLineWidth(0.6)
        for gx in range(0, int(W), 28):
            c.line(gx, 0, gx, H - 40 * mm)
        for gy in range(0, int(H - 40 * mm), 28):
            c.line(0, gy, W, gy)
        c.setFillColor(GOLD)
        c.setFont('BC-B', 13)
        c.drawString(M, H - 70 * mm, 'INFORMÁTICA  ·  SEGURANÇA DA INFORMAÇÃO')
        c.setFillColor(colors.white)
        c.setFont('BC-B', 46)
        c.drawString(M, H - 92 * mm, 'VÍRUS E OUTROS')
        c.drawString(M, H - 109 * mm, 'CÓDIGOS MALICIOSOS')
        c.setFillColor(GOLD)
        c.rect(M, H - 118 * mm, 60 * mm, 2.2, stroke=0, fill=1)
        c.setFillColor(colors.HexColor('#C9D4E5'))
        c.setFont('B', 13)
        c.drawString(M, H - 128 * mm, 'Teoria, quadro comparativo, mapa mental e 10 questões no estilo Cebraspe')
        c.drawString(M, H - 135 * mm, 'com gabarito comentado.')
        # cartão "neste material"
        y0 = H - 205 * mm
        c.setFillColor(PANEL)
        c.roundRect(M, y0, W - 2 * M, 56 * mm, 8, stroke=0, fill=1)
        c.setFillColor(GOLD2)
        c.setFont('BC-B', 11)
        c.drawString(M + 8 * mm, y0 + 47 * mm, 'NESTE MATERIAL')
        items = [('01', 'Teoria', 'malware, vírus, worm, bot, trojan, spyware, backdoor, rootkit, ransomware'),
                 ('02', 'Resumo', 'quadro comparativo e “leve para a prova”'),
                 ('03', 'Mapa mental', 'uma página para revisar em 5 minutos'),
                 ('04', 'Questões', '10 itens certo/errado + gabarito comentado')]
        for i, (n, t, s) in enumerate(items):
            yy = y0 + 37 * mm - i * 9 * mm
            c.setFillColor(GOLD)
            c.setFont('BC-B', 14)
            c.drawString(M + 8 * mm, yy, n)
            c.setFillColor(colors.white)
            c.setFont('BC-B', 13)
            c.drawString(M + 20 * mm, yy, t.upper())
            c.setFillColor(colors.HexColor('#8EA0BC'))
            c.setFont('B', 10)
            c.drawString(M + 50 * mm, yy, s)
        c.setFillColor(colors.HexColor('#8EA0BC'))
        c.setFont('B', 9)
        c.drawString(M, 30 * mm, 'Tópico do edital: Malwares, ataques e golpes (Informática)')
        c.drawString(M, 25 * mm, 'Base: Cartilha de Segurança para Internet (CERT.br), referência das bancas.')
        c.setFillColor(GOLD)
        c.setFont('BC-B', 10)
        c.drawString(M, 17 * mm, f"VERSÃO {C.MATERIAL['version']}  ·  NOVEMBRO DE 2026  ·  {C.MATERIAL['status'].upper()}")
        c.restoreState()

    LW, LH = landscape(A4)
    frame = Frame(M, 18 * mm, fw, H - 40 * mm, id='f', leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)
    lframe = Frame(M, 14 * mm, LW - 2 * M, LH - 32 * mm, id='lf', leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)
    doc.addPageTemplates([
        PageTemplate(id='cover', frames=[Frame(M, M, fw, H - 2 * M, id='c')], onPage=cover, pagesize=A4),
        PageTemplate(id='page', frames=[frame], onPage=header, pagesize=A4),
        PageTemplate(id='land', frames=[lframe], onPage=header_land, pagesize=landscape(A4)),
    ])

    story = [NextPageTemplate('page'), PageBreak()]

    def render(blocks):
        out = []
        for b in blocks:
            t = b['t']
            if t == 'h2':
                out.append(SectionTitle(b['text'], fw))
            elif t == 'h3':
                out.append(Paragraph(md(b['text']), S['h3']))
            elif t == 'p':
                out.append(Paragraph(md(b['text']), S['body']))
            elif t == 'bullets':
                out += bullets(b['items'])
            elif t == 'callout':
                out.append(callout(b['style'], b['title'], b['text'], fw))
            elif t == 'table':
                out += table(b['head'], b['rows'], b['widths'], fw)
            elif t == 'note':
                out.append(Paragraph(md(b['text']), S['note']))
        return out

    story += render(C.THEORY)
    story.append(PageBreak())
    story += render([b for b in C.SUMMARY if b['t'] != 'mindmap'])
    story += [NextPageTemplate('land'), PageBreak()]
    story.append(MindMap(C.MINDMAP, LW - 2 * M, LH - 34 * mm))
    story += [NextPageTemplate('page'), PageBreak()]
    story.append(SectionTitle('Questões · estilo Cebraspe', fw))
    story.append(Spacer(1, 4))
    story.append(Paragraph(md(C.QUIZ['instructions']), S['body']))
    story.append(Spacer(1, 6))
    for i, q in enumerate(C.QUIZ['questions'], start=1):
        story.append(QuestionBox(i, q['text'], fw))
        story.append(Spacer(1, 6))
    story.append(PageBreak())
    story.append(SectionTitle('Gabarito comentado', fw))
    story.append(Spacer(1, 6))
    gab = [[Paragraph('ITEM', S['head']), Paragraph('GAB.', S['head']), Paragraph('COMENTÁRIO', S['head'])]]
    for i, q in enumerate(C.QUIZ['questions'], start=1):
        col = '#0F766E' if q['answer'] == 'C' else '#C2410C'
        gab.append([Paragraph(f'<b>{i:02d}</b>', S['cellb']),
                    Paragraph(f'<font color="{col}"><b>{q["answer"]}</b></font>',
                              ParagraphStyle('g', parent=S['cellb'], fontSize=12, alignment=TA_CENTER)),
                    Paragraph(md(q['comment']), S['qc'])])
    t = Table(gab, colWidths=[0.08 * fw, 0.08 * fw, 0.84 * fw], repeatRows=1)
    st = [('BACKGROUND', (0, 0), (-1, 0), NAVY), ('LINEBELOW', (0, 0), (-1, 0), 1.5, GOLD), ('VALIGN', (0, 0), (-1, -1), 'TOP'),
          ('LEFTPADDING', (0, 0), (-1, -1), 7), ('RIGHTPADDING', (0, 0), (-1, -1), 7), ('TOPPADDING', (0, 0), (-1, -1), 6),
          ('BOTTOMPADDING', (0, 0), (-1, -1), 7), ('LINEBELOW', (0, 1), (-1, -1), 0.4, LINE)]
    for i in range(2, len(gab), 2):
        st.append(('BACKGROUND', (0, i), (-1, i), ZEBRA))
    t.setStyle(TableStyle(st))
    story.append(t)
    story.append(Spacer(1, 14))
    story.append(Paragraph('<b>FONTES</b>', ParagraphStyle('fs', parent=S['note'], textColor=NAVY, fontName='BC-B', fontSize=10)))
    for s in C.SOURCES:
        story.append(Paragraph(md(s), S['note']))
    doc.build(story)


def build_json(path):
    mat = dict(C.MATERIAL)
    mat['sections'] = [
        {'id': 'teoria', 'title': 'Teoria', 'blocks': C.THEORY},
        {'id': 'resumo', 'title': 'Resumo + mapa mental', 'blocks': C.SUMMARY},
    ]
    mat['mindmap'] = C.MINDMAP
    mat['quiz'] = C.QUIZ
    mat['sources'] = C.SOURCES
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(mat, f, ensure_ascii=False, indent=1)


if __name__ == '__main__':
    pdf = os.path.join(OUT_DIR, C.MATERIAL['pdf'])
    build_pdf(pdf)
    build_json(os.path.join(OUT_DIR, 'material.json'))
    index = {
        'version': '2026.11.1',
        'materials': [{
            'id': C.MATERIAL['id'], 'folder': 'informatica_virus', 'title': C.MATERIAL['title'], 'subtitle': C.MATERIAL['subtitle'],
            'subjectId': C.MATERIAL['subjectId'], 'topicIds': C.MATERIAL['topicIds'], 'kind': C.MATERIAL['kind'],
            'minutes': C.MATERIAL['minutes'], 'questions': len(C.QUIZ['questions']), 'version': C.MATERIAL['version'],
            'status': C.MATERIAL['status'],
        }],
    }
    with open(os.path.join(PROJ, 'assets', 'content', 'index.json'), 'w', encoding='utf-8') as f:
        json.dump(index, f, ensure_ascii=False, indent=1)
    if EXTRA:
        os.makedirs(EXTRA, exist_ok=True)
        shutil.copy(pdf, os.path.join(EXTRA, 'Mentor_Policial_Informatica_Virus_v0.1.pdf'))
    print('ok', pdf)
